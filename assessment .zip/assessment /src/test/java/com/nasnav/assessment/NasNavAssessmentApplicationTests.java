package com.nasnav.assessment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NasNavAssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
